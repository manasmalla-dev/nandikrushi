package com.toki.leomath

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.ui.graphics.vector.ImageVector

sealed class Screen(
    val id:String,
    val title:String,
    val icon: ImageVector,
) {


    object Home : Screen("home", "Home", Icons.Outlined.Home)
    object Kids : Screen("kids", "Kids", Icons.Outlined.Search)
    object Comedy : Screen("comedy", "Comedy", Icons.Outlined.Person)
    object Fiction : Screen("fiction", "Fiction", Icons.Outlined.Settings)

    object Items {
        val list = listOf(
            Home, Kids, Comedy, Fiction
        )
    }

}
