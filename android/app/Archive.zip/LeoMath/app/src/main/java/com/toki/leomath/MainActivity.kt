package com.toki.leomath

import android.annotation.SuppressLint
import android.os.Build
import android.os.Bundle
import android.view.WindowInsetsController
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.google.accompanist.systemuicontroller.rememberSystemUiController
import com.toki.leomath.ui.theme.LeoMathTheme
import kotlinx.coroutines.delay
import java.nio.file.WatchEvent


class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Turn off the decor fitting system windows, which allows us to handle insets,
        // including IME animations
        
        setContent {

            LeoMathTheme {
                // A surface container using the 'background' color from the theme
                Splash()
                LaunchedEffect(key1 = this,){
                    delay(5000)
                    setContent { Nav() }
                }
            }
        }
    }
}
@SuppressLint("UnrememberedMutableState")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Nav() {
    val scrollState = rememberScrollState()

    val currentScreen = mutableStateOf<Screen>(Screen.Home)
    val navController = rememberNavController()
    Scaffold(
        bottomBar = {
            CustomBottomNavigation(currentScreenId = currentScreen.value.id) {
                currentScreen.value = it
                navController.navigate(it.id)
            }
        }
    ) { innerPadding ->

        Image(painter = painterResource(id = R.drawable.splash_screen_port), contentDescription = "", contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
        Surface(
            Modifier
                .fillMaxSize()
                .padding(10.dp, 10.dp, 10.dp, 85.dp)
                .clip(RoundedCornerShape(8.dp))) {

        }
        NavHost(
            navController,
            startDestination = Screen.Home.id,
            Modifier.padding(innerPadding)
        ) {
            composable(Screen.Home.id) {
                Column(
                    Modifier
                        .fillMaxSize()
                        .padding(25.dp)
                        .verticalScroll(scrollState),
                ) {
                    Surface(
                        Modifier
                            .fillMaxWidth()
                            .height(100.dp)
                            .padding(10.dp)
                            .shadow(12.dp)
                            .clip(RoundedCornerShape(8.dp))
                    ) {

                        Row(
                            Modifier
                                .fillMaxSize()
                                .padding(10.dp), horizontalArrangement = Arrangement.Center
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.fox),
                                contentDescription = ""
                            )

                        }

                    }
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .height(150.dp)
                    ) {

                            Image(
                                painter = painterResource(id = R.drawable.trace),
                                contentDescription = "",
                                modifier = Modifier.fillMaxWidth(0.5f).fillMaxHeight().padding(10.dp)
                            )
                        Image(
                            painter = painterResource(id = R.drawable.time),
                            contentDescription = "",
                            modifier = Modifier.fillMaxSize().padding(10.dp)

                        )



                    }
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .height(150.dp)
                    ) {

                        Image(
                            painter = painterResource(id = R.drawable.frog_a_matic),
                            contentDescription = "",
                            modifier = Modifier.fillMaxWidth(0.5f).fillMaxHeight().padding(10.dp)
                        )
                        Image(
                            painter = painterResource(id = R.drawable.chicken_count),
                            contentDescription = "",
                            modifier = Modifier.fillMaxSize().padding(10.dp)

                        )



                    }
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .height(150.dp)
                    ) {

                        Image(
                            painter = painterResource(id = R.drawable.trace),
                            contentDescription = "",
                            modifier = Modifier.fillMaxWidth(0.5f).fillMaxHeight().padding(10.dp)
                        )
                        Image(
                            painter = painterResource(id = R.drawable.time),
                            contentDescription = "",
                            modifier = Modifier.fillMaxSize().padding(10.dp)

                        )



                    }
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .height(150.dp)
                    ) {

                        Image(
                            painter = painterResource(id = R.drawable.frog_a_matic),
                            contentDescription = "",
                            modifier = Modifier.fillMaxWidth(0.5f).fillMaxHeight().padding(10.dp)
                        )
                        Image(
                            painter = painterResource(id = R.drawable.chicken_count),
                            contentDescription = "",
                            modifier = Modifier.fillMaxSize().padding(10.dp)

                        )



                    }
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .height(150.dp)
                    ) {

                        Image(
                            painter = painterResource(id = R.drawable.trace),
                            contentDescription = "",
                            modifier = Modifier.fillMaxWidth(0.5f).fillMaxHeight().padding(10.dp)
                        )
                        Image(
                            painter = painterResource(id = R.drawable.time),
                            contentDescription = "",
                            modifier = Modifier.fillMaxSize().padding(10.dp)

                        )



                    }




                }
                  
            }
            composable(Screen.Kids.id) {

            }
            composable(Screen.Comedy.id) {

            }
            composable(Screen.Fiction.id) {

            }

        }


    }
}



@Preview
@Composable
fun Previews(){
    Nav()
}

